<?php
include("student_header.php");
?>
<!-- Tags Start -->
<div class="mb-5 wow slideInUp" data-wow-delay="0.1s">
                        <div class="section-title section-title-sm position-relative pb-3 mb-4">
                            <h3 class="mb-0">Tasks</h3>
                        </div>
                        <div class="d-flex flex-wrap m-n1">
                            <a href="stud_add_intern_details.php" class="btn btn-light m-1">Add Internship Details</a>
                            <a href="stud_add_project_details.php" class="btn btn-light m-1">Add Project Details</a>
                            <a href="stud_submit_tasks.php" class="btn btn-light m-1">Student Submit Tasks</a>
                            <a href="stud_profile.php" class="btn btn-light m-1">Profile</a>
                        </div>
                    </div>
                    <!-- Tags End -->
<?php
include("footer.php");
?>