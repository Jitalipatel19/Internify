<?php
include("faculty_header.php");
?>
<!-- Tags Start -->
<div class="mb-5 wow slideInUp" data-wow-delay="0.1s">
                        <div class="section-title section-title-sm position-relative pb-3 mb-4">
                            <h3 class="mb-0">Tasks</h3>
                        </div>
                        <div class="d-flex flex-wrap m-n1">
                            <a href="faculty_view_assigned_stud.php" class="btn btn-light m-1">View Students Assigned</a>
                            <a href="faculty_manage_project.php" class="btn btn-light m-1">Manage Projects</a>
                            <a href="faculty_manage_score.php" class="btn btn-light m-1">Manage Scores</a>
                            <a href="faculty_profile.php" class="btn btn-light m-1">Profile</a>
                        </div>
                    </div>
                    <!-- Tags End -->
<?php
include("footer.php");
?>