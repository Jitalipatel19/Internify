<?php
$conn=mysqli_connect("localhost","root","") or die("Connection Failed");
mysqli_select_db($conn,"internship");
?>